﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TTF_Native
{
    public class TTF_Model//:ITTF_Model
    {
        public _inputs inputs = new _inputs();
        public _outputs outputs = new _outputs();

        public class _inputs
        {
            private bool _A = false;
            private bool _B = false;
            private bool _C = false;

            private int _D = -1;
            private int _E = -1;
            private int _F = -1;

            public bool A { get { return _A; } set { _A = value; } }
            public bool B { get { return _B; } set { _B = value; } }
            public bool C { get { return _C; } set { _C = value; } }

            public int D { get { return _D; } set { _D = value; } }
            public int E { get { return _E; } set { _E = value; } }
            public int F { get { return _F; } set { _F = value; } }

        }

        public class _outputs
        {
            public enum SRT { S, R, T }

            private SRT _X = SRT.S;
            private decimal _Y = -1;

            private bool _X_changed = false;

            public SRT X { get { return _X; } set { _X = value; _X_changed = true; } }
            public decimal Y { get { return _Y; } set { _Y = value; } }
            public bool X_changed { get { return _X_changed; } }
        }

        public virtual void map_x(bool throw_error)
        {

            if ((this.inputs.A) && (this.inputs.B) && (!this.inputs.C))
            {
                this.outputs.X = _outputs.SRT.S;
            }
            else if ((this.inputs.A) && (this.inputs.B) && (this.inputs.C))
            {
                this.outputs.X = _outputs.SRT.R;
            }
            else if ((!this.inputs.A) && (this.inputs.B) && (this.inputs.C))
            {
                this.outputs.X = _outputs.SRT.T;
            }

            if ((throw_error) && (!this.outputs.X_changed))
            {

                throw new Exception("wrong boolean inputs ABC");
            }
        }

        /// <summary>
        /// calculate x output
        /// </summary>
        public virtual void map_x()
        {
            this.map_x(false);
        }

        /// <summary>
        /// calculate y output
        /// </summary>
        public virtual void map_y()
        {
            if (this.outputs.X == _outputs.SRT.S)
            {
                this.outputs.Y = this.inputs.D + (this.inputs.D * Convert.ToDecimal(this.inputs.E) / 100);
            }

            if (this.outputs.X == _outputs.SRT.R)
            {
                this.outputs.Y = this.inputs.D + (this.inputs.D * Convert.ToDecimal((this.inputs.E - this.inputs.F)) / 100);
            }

            if (this.outputs.X == _outputs.SRT.T)
            {
                this.outputs.Y = this.inputs.D + (this.inputs.D * Convert.ToDecimal(this.inputs.F) / 100);
            }
        }


    }

    public class TTF_Spec1 : TTF_Model
    {
        public override void map_y()
        {
            base.map_y();

            if (this.outputs.X == _outputs.SRT.R)
            {
                this.outputs.Y = 2 * this.inputs.D +
                    (this.inputs.D * this.inputs.E / 100);
            }
        }
    }


    public class TTF_Spec2 : TTF_Model
    {
        public override void map_x()
        {
            base.map_x(false);

            if ((this.inputs.A) && (this.inputs.B) && (!this.inputs.C))
            {
                this.outputs.X = _outputs.SRT.T;
            }

            if ((this.inputs.A) && (!this.inputs.B) && (this.inputs.C))
            {
                this.outputs.X = _outputs.SRT.S;
            }

            if (!this.outputs.X_changed)
            {

                throw new Exception("wrong boolean inputs ABC");
            }
        }

        public override void map_y()
        {
            base.map_y();

            if (this.outputs.X == _outputs.SRT.S)
            {
                this.outputs.Y = this.inputs.F + this.inputs.D +
                    (this.inputs.D * this.inputs.E / 100);
            }

        }
    }
}