﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TTF_Native;

namespace TTF_Native.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            TTF_Model t = new TTF_Model();
            t.inputs.A = true;
            t.inputs.B = true;
            t.inputs.C = true;
            t.map_x();
            Assert.AreEqual("R", t.outputs.X);
        }
    }
}
